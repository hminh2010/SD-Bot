#Put your bots token here
TOKEN = ""

#Your desired prefix
PREFIX = ""

#Your bots name
BOTNAME = ""
