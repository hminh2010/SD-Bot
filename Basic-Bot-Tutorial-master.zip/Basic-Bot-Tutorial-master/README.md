<!DOCTYPE html>
<html>
<body>

<h2>Basic Bot Tutorial</h2>

<p>A Repo For My Discord Bot Tutorial. Please follow all the steps listed here and on the video!</p>

<h2>How To Install</h2>

<h2>Video Tutorial!</h2>

<p>https://youtu.be/uz0nvfiynHY</p>

<p>1) Install Python 3.6.4 (Download Link <a href="https://www.python.org/ftp/python/3.6.4/python-3.6.4.exe">Here</a>).</p>

<p>2) Add Python to PATH (As Shown Below)</p>
<img src="https://1.bp.blogspot.com/-Iv2_eAzb3u8/WkNgYosQ1qI/AAAAAAAAAgw/PbWccmDJWiI5RfSOLGZeiwJCmOVVBDKKQCLcBGAs/s1600/Python%2Bsetup.PNG" alt="Mountain View" width="500" height="300">

<p>3) Type "pip install discord.py" into cmd</p>

<p>4) Type "pip install datetime" into cmd</p>

<p>Your All Done, Move on to Configurations below!</p>

<h2>Configurations</h2>

<p>1) To get your bot token click <a href="https://discordapp.com/developers/applications/me">Here</a>. Then click your bot, scroll down till you find "Token: click to reveal". copy that token and paste it in the Config.py file where it says TOKEN = "Your Token"</p>

<p>2) Select a prefix and type it in the Config.py file under PREFIX. Example: If i want my prefix to be "t." i would do this in the Config.py file under PREFIX = "t.".</p>

<p>3) Insert Your bots name into to Config.py file under "BOTNAME = "Your Bot Name".</p>

<p> Now Just double click Main.py And your bot should get online!</p>

<h2>If You Have Any Issues: </h2>

<p>Join My Support Server <a href="https://discord.gg/aXZMuCN">Here</a>

</body>
</html>
